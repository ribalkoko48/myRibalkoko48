import React, { useCallback, useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators, Dispatch } from 'redux';
import { IAppState } from 'store/types';
// import style from './$style_module.scss';

const mapStateToProps = (state: IAppState) => ({});

const mapDispatchToProps = (dispatch: Dispatch) => bindActionCreators({}, dispatch);

type Props = ReturnType<typeof mapStateToProps> & ReturnType<typeof mapDispatchToProps>;

const $Component_Component: React.FC<Props> = (props: Props) => {
    /* useEffect(() => {
    }, []); */

    /* const handleSubmit = useCallback(() => {
    }, []); */

    return <div className={style.wrapper}>$Component</div>;
};

export const $Component = connect(mapStateToProps, mapDispatchToProps)($Component_Component);