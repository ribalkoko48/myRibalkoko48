import * as React from 'react';
import style from './$name.module.scss';

interface IProps$Component {
    isActive: boolean;
}

/*interface IState$Component {

}*/

export const $Component: React.FC<IProps$Component & IState$Component> = (props: IProps$Component & IState$Component) => {
    return (
        <div className={style.$name}>
            $Component
        </div>
    )
};